/* bank project
 Yahel Tsufim 304952898
 Noam Stolero 201581683
 file:menu.h
 */

#ifndef menu_h
#define menu_h

#include "bank.h"




void mainMenu();/*the main menu of the testing code*/
void add_Delete_Menu();/*add client/branch or delete client/branch*/
void infoMenu();/*check bank/branch/client information*/
void transactionAndReports();/*deposit money, loan money, get details about branch and bank costumers*/


#endif
